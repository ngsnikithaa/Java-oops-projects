package com.sj.empmanagmentapplication;

import java.util.HashSet;
import java.util.Scanner;
import java.util.InputMismatchException;


public class EmployeeService {

    HashSet<Employee> empset = new HashSet<>();

    Employee emp1 = new Employee(101, "Shital", 24, "Developer", "IT", 25000);
    Employee emp2 = new Employee(102, "Meena", 26, "Tester", "CO", 57000);
    Employee emp3 = new Employee(103, "Bob", 20, "DevOps Engineer", "Admin", 50000);
    Employee emp4 = new Employee(104, "Max", 27, "System Engineer", "CO", 70000);

    Scanner sc = new Scanner(System.in);
    boolean found = false;
    int id;
    String name;
    int age;
    String department;
    String designation;
    double salary;

    public EmployeeService() {
        empset.add(emp1);
        empset.add(emp2);
        empset.add(emp3);
        empset.add(emp4);
    }

    // View all employees
    public void viewAllEmps() {
        for (Employee emp : empset) {
            System.out.println(emp);
        }
    }

    // View employee based on ID
    public void viewEmp() {
        System.out.print("Enter Employee ID: ");
        id = sc.nextInt();
        found = false;

        for (Employee emp : empset) {
            if (emp.getId() == id) {
                System.out.println(emp);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Employee with this ID is not present.");
        }
    }

    // Update an employee
    public void updateEmployee() {
        System.out.print("Enter Employee ID: ");
        id = sc.nextInt();
        found = false;

        for (Employee emp : empset) {
            if (emp.getId() == id) {
                System.out.print("Enter New Name: ");
                name = sc.next();
                System.out.print("Enter New Salary: ");
                salary = sc.nextDouble();
                emp.setName(name);
                emp.setSalary(salary);
                System.out.println("Updated Employee Details: ");
                System.out.println(emp);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Employee not found.");
        } else {
            System.out.println("Employee details updated successfully!");
        }
    }

    // Delete an employee
    public void deleteEmp() {
        System.out.print("Enter Employee ID to Delete: ");
        id = sc.nextInt();
        found = false;
        Employee empToDelete = null;

        for (Employee emp : empset) {
            if (emp.getId() == id) {
                empToDelete = emp;
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Employee not found.");
        } else {
            empset.remove(empToDelete);
            System.out.println("Employee deleted successfully!");
        }
    }

    // Add an employee
    // Add Employee Method with Input Validation
    public void addEmp() {
        try {
            System.out.print("Enter ID: ");
            id = Integer.parseInt(sc.nextLine()); // Read ID and clear buffer

            System.out.print("Enter Name: ");
            name = sc.nextLine(); // Read Name, which can include spaces

            System.out.print("Enter Age: ");
            age = Integer.parseInt(sc.nextLine()); // Read Age and clear buffer

            System.out.print("Enter Designation: ");
            designation = sc.nextLine(); // Read Designation

            System.out.print("Enter Department: ");
            department = sc.nextLine(); // Read Department

            System.out.print("Enter Salary: ");
            salary = Double.parseDouble(sc.nextLine()); // Read Salary and clear buffer

            Employee emp = new Employee(id, name, age, designation, department, salary);
            empset.add(emp);

            System.out.println("Employee added successfully!");
            System.out.println(emp);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for ID, Age, and Salary.");
        }
    }


}
